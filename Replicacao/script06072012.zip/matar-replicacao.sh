killall recebe-pfcg.sh -9
killall recebe-pfcat.sh -9
killall recebe-pfpv.sh -9
killall recebe-pfmos.sh -9

killall envia-pfcg.sh -9
killall envia-pfcat.sh -9
killall envia-pfpv.sh -9
killall envia-pfmos.sh -9

killall isql -9
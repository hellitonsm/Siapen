rm xxxxx.parar
cp /etc/1crontab /etc/crontab


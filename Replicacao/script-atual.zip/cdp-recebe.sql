connect 'localhost:siapen' user 'REPLICADOR' password 'SIAPSIAP';
execute procedure sp_replicacao_recebimento(2);
commit;

exit;




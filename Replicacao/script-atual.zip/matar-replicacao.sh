cp /etc/2crontab /etc/crontab
cp ativa-replicacao.sh xxxxx.parar
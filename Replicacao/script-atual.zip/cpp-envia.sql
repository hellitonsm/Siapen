connect 'localhost:siapen' user 'SYSDBA' password '!p@a#p$1';
execute procedure sp_replicacao_envio(7);
commit;
exit;




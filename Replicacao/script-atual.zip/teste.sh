#!/bin/sh
arquivo=xxxxx.parar
lista=`ls -l`
lista=`echo ${lista#* ${arquivo}}`
executando=`echo ${lista}`
quantidade=`echo ${#executando}`
if [ $quantidade -lt 17 ]; then
   echo "sim: $quantidade comando: $executando"
else
   echo "nao: $quantidade comando: $executando"
fi


